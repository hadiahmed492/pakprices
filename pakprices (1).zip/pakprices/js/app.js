// ============================================================
// PakPrices — Main App Logic
// ============================================================

let currentCat = 'all';
let currentQuery = '';

// Helper: format price as Rs 89,999
function fmt(n) {
  return 'Rs ' + n.toLocaleString('en-PK');
}

// Get min price across all stores
function minPrice(p) {
  return Math.min(...p.prices.map(x => x.price));
}

// Get max price across all stores
function maxPrice(p) {
  return Math.max(...p.prices.map(x => x.price));
}

// Get savings amount
function savings(p) {
  return maxPrice(p) - minPrice(p);
}

// Get best store object
function bestStore(p) {
  return p.prices.find(x => x.price === minPrice(p));
}

// Escape single quotes for safe use in inline onclick strings
function esc(str) {
  return str.replace(/'/g, "\\'");
}

// Escape HTML special chars to safely inject into innerHTML
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Get filtered + sorted list
function getFiltered() {
  let list = [...PRODUCTS];

  // Category filter
  if (currentCat !== 'all') {
    list = list.filter(p => p.category === currentCat);
  }

  // Search filter
  if (currentQuery) {
    const q = currentQuery.toLowerCase();
    list = list.filter(p => p.name.toLowerCase().includes(q));
  }

  // Sort
  const sort = document.getElementById('sortSelect').value;
  if (sort === 'price-asc') list.sort((a, b) => minPrice(a) - minPrice(b));
  else if (sort === 'price-desc') list.sort((a, b) => minPrice(b) - minPrice(a));
  else if (sort === 'savings') list.sort((a, b) => savings(b) - savings(a));

  return list;
}

// Render product cards
function renderProducts(list) {
  const grid = document.getElementById('productsGrid');
  const noResults = document.getElementById('noResults');
  const countEl = document.getElementById('resultsCount');

  if (list.length === 0) {
    grid.innerHTML = '';
    noResults.style.display = 'block';
    countEl.textContent = '0 products found';
    return;
  }

  noResults.style.display = 'none';
  countEl.textContent = `Showing ${list.length} product${list.length !== 1 ? 's' : ''}`;

  grid.innerHTML = list.map(p => {
    const best = bestStore(p);
    const sv = savings(p);
    const sortedPrices = [...p.prices].sort((a, b) => a.price - b.price);

    return `
      <div class="product-card" onclick="openModal(${p.id})">
        <div class="card-top">
          <div class="card-img">${escHtml(p.emoji)}</div>
          <div class="card-info">
            <div class="card-name">${escHtml(p.name)}</div>
            <div class="card-cat">${escHtml(p.category)}</div>
            <div class="best-price-label">Best price</div>
            <div class="best-price-value">${fmt(minPrice(p))}</div>
            <div class="best-price-store">on ${escHtml(best.store)}</div>
            ${sv > 0 ? `<div class="savings-tag">💚 Save ${fmt(sv)}</div>` : ''}
          </div>
        </div>
        <div class="price-stores">
          ${sortedPrices.map((pr, i) => `
            <div class="store-row">
              <div class="store-left">
                <div class="store-dot" style="background:${escHtml(pr.color)}"></div>
                <span class="store-name-text">${escHtml(pr.store)}</span>
                ${i === 0 ? '<span class="best-badge">Best</span>' : ''}
              </div>
              <div class="store-right">
                <span class="store-price-text ${i === 0 ? 'best' : ''}">${fmt(pr.price)}</span>
                <button class="visit-btn" onclick="event.stopPropagation(); visitStore('${pr.url}', '${esc(pr.store)}', '${esc(p.name)}')">Visit</button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
}

// Open modal
function openModal(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;

  const best = bestStore(p);
  const sv = savings(p);
  const sortedPrices = [...p.prices].sort((a, b) => a.price - b.price);

  document.getElementById('modalContent').innerHTML = `
    <div class="modal-product-name">${escHtml(p.emoji)} ${escHtml(p.name)}</div>
    <div class="modal-cat">${escHtml(p.category)}</div>
    <div class="modal-best">
      <div class="modal-best-label">✅ Best Price Found</div>
      <div class="modal-best-price">${fmt(minPrice(p))}</div>
      <div class="modal-best-store">Available on ${escHtml(best.store)} ${sv > 0 ? `· You save ${fmt(sv)}` : ''}</div>
    </div>
    <div class="modal-all-title">All Prices</div>
    ${sortedPrices.map((pr, i) => `
      <div class="modal-store-row">
        <div class="store-left">
          <div class="store-dot" style="background:${escHtml(pr.color)}"></div>
          <span class="store-name-text">${escHtml(pr.store)}</span>
          ${i === 0 ? '<span class="best-badge">Cheapest</span>' : ''}
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <span class="store-price-text ${i === 0 ? 'best' : ''}">${fmt(pr.price)}</span>
          <button class="modal-visit-btn" onclick="visitStore('${pr.url}', '${esc(pr.store)}', '${esc(p.name)}')">Go to ${escHtml(pr.store)}</button>
        </div>
      </div>
    `).join('')}
  `;

  document.getElementById('modalOverlay').classList.add('open');
}

// Close modal
function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
}

// Visit store (tracks affiliate clicks)
function visitStore(url, store, product) {
  // In a real site: track this click for analytics/affiliate
  console.log(`Click: ${product} on ${store}`);
  window.open(url, '_blank');
}

// Search
function doSearch() {
  currentQuery = document.getElementById('searchInput').value.trim();
  renderProducts(getFiltered());
}

function quickSearch(query) {
  document.getElementById('searchInput').value = query;
  currentQuery = query;
  currentCat = 'all';
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.cat-btn')[0].classList.add('active');
  renderProducts(getFiltered());
}

function resetSearch() {
  document.getElementById('searchInput').value = '';
  currentQuery = '';
  currentCat = 'all';
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.cat-btn')[0].classList.add('active');
  renderProducts(getFiltered());
}

// Category filter
function filterCat(cat, el) {
  currentCat = cat;
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  renderProducts(getFiltered());
}

// Mobile menu
function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

// Close modal on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

// Init
renderProducts(getFiltered());
