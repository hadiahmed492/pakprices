// ============================================================
// PRODUCT DATA — Add more products here as you grow!
// To add a product: copy one object, change the values, done.
// ============================================================

const PRODUCTS = [
  {
    id: 1,
    name: "Samsung Galaxy A55 5G",
    category: "mobile",
    emoji: "📱",
    prices: [
      { store: "Daraz",  price: 89999, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 95000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 97500, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 2,
    name: "Apple iPhone 15 128GB",
    category: "mobile",
    emoji: "📱",
    prices: [
      { store: "Daraz",  price: 289000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 270000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 295000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 3,
    name: "Xiaomi Redmi Note 13",
    category: "mobile",
    emoji: "📱",
    prices: [
      { store: "Daraz",  price: 54999, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 51000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 57000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 4,
    name: "HP Laptop 15s Core i5 12th Gen",
    category: "laptop",
    emoji: "💻",
    prices: [
      { store: "Daraz",  price: 145000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 132000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 150000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 5,
    name: "Dell Inspiron 15 Core i7",
    category: "laptop",
    emoji: "💻",
    prices: [
      { store: "Daraz",  price: 195000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 180000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 199000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 6,
    name: "Haier 1.5 Ton Inverter AC",
    category: "appliance",
    emoji: "❄️",
    prices: [
      { store: "Daraz",  price: 115000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 98000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 120000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 7,
    name: "Dawlance Refrigerator 12 cu ft",
    category: "appliance",
    emoji: "🧊",
    prices: [
      { store: "Daraz",  price: 87000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 79000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 91000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 8,
    name: "Nike Air Max 270 (Size 42)",
    category: "fashion",
    emoji: "👟",
    prices: [
      { store: "Daraz",  price: 24500, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 21000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 26000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 9,
    name: "Samsol Rice 5kg Basmati",
    category: "grocery",
    emoji: "🌾",
    prices: [
      { store: "Daraz",  price: 1850, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 1700, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 1950, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 10,
    name: "Sony WH-1000XM5 Headphones",
    category: "mobile",
    emoji: "🎧",
    prices: [
      { store: "Daraz",  price: 89000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 82000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 92000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 11,
    name: "Samsung 55-inch 4K Smart TV",
    category: "appliance",
    emoji: "📺",
    prices: [
      { store: "Daraz",  price: 185000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 170000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 192000, url: "#", color: "#F59E0B" }
    ]
  },
  {
    id: 12,
    name: "Lenovo IdeaPad Slim 3 Core i3",
    category: "laptop",
    emoji: "💻",
    prices: [
      { store: "Daraz",  price: 98000, url: "https://www.daraz.pk/", color: "#EF4444" },
      { store: "OLX",    price: 89000, url: "https://www.olx.com.pk/", color: "#0EA5E9" },
      { store: "Local",  price: 102000, url: "#", color: "#F59E0B" }
    ]
  }
];
